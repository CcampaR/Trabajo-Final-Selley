<?php
    $con=mysqli_connect("localhost","root","","proyectofinal");

    // Check connection
    if (mysqli_connect_errno()) {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }

    // escape variables for security
    $nombre = mysqli_real_escape_string($con, $_POST['nombre']);
    $fecha = mysqli_real_escape_string($con, $_POST['fecha']);
    $correo = mysqli_real_escape_string($con, $_POST['correo']);
    $contrasena = mysqli_real_escape_string($con, $_POST['contrasena']);
    $direccion = mysqli_real_escape_string($con, $_POST['direccion']);
	$pais = mysqli_real_escape_string($con, $_POST['pais']);
    $tarjeta = mysqli_real_escape_string($con, $_POST['tarjeta']);
    $sql="INSERT INTO usuarios(nombre_usuario, correo_usuario, contrasena_usuario, nacimiento_usuario, 
    tarjeta_usuario, direccion_usuario, pais_usuario) 
    VALUES ('$nombre','$correo','$contrasena','$fecha',$tarjeta,'$direccion','$pais');";

    if (!mysqli_query($con,$sql)) {
      die('Error: ' . mysqli_error($con));
    }
    

    mysqli_close($con);
    
    header("Location: index.php);
  ?>