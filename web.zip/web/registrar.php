<?php
    session_start();
    $con=mysqli_connect("localhost","root","","proyectofinal");

    // Check connection
    if (mysqli_connect_errno()) {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }

    // escape variables for security
    $nombre = mysqli_real_escape_string($con, $_POST['nombre']);
    //$apellido = mysqli_real_escape_string($con, $_POST['apellido']);
    $correo = mysqli_real_escape_string($con, $_POST['correo']);
    $contrasena = mysqli_real_escape_string($con, $_POST['contrasena']);
    $direccion = mysqli_real_escape_string($con, $_POST['direccion']);
	  $fecha = mysqli_real_escape_string($con, $_POST['fecha']);
    $sql="INSERT INTO usuarios (Nombre usuario, correo electronico, contrasena, fecha de nacimiento, Direccion Postal) 
    VALUES ('$nombre','$correo','$contrasena','$fecha',$direccion);";

    if (!mysqli_query($con,$sql)) {
      die('Error: ' . mysqli_error($con));
    }
    mysqli_close($con);
    
    header("Location: index.php");
  ?>